from django.conf.urls import url
from complaint import views
urlpatterns=[
    url('^comp/',views.comp),
    url('^viewcomp/',views.vcomplaint),
    url('^cmpnt_reply/',views.vcompandreplay),
    url('^reply/(?P<idd>\w+)',views.reply, name='reply'),
    url('forwr/(?P<idd>\w+)',views.forward,name='frwrd'),
    url('^vrply/',views.vrply),


]