from django.db import models

# Create your models here.
class Complaint(models.Model):
    c_id = models.AutoField(primary_key=True)
    complaint = models.CharField(max_length=100)
    u_id = models.IntegerField()
    date = models.DateField()
    time = models.TimeField()
    status = models.CharField(max_length=50)
    replay = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'complaint'
