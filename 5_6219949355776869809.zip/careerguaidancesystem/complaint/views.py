from django.shortcuts import render
from complaint.models import Complaint
import datetime
# Create your views here.
def comp(request):
    cc= request.session["u_id"]
    if request.method=="POST":
        obj = Complaint()
        obj.complaint=request.POST.get('COMPLAINT')
        obj.replay = "pending"
        obj.date = datetime.date.today()
        obj.time = datetime.datetime.now()
        obj.status = "pending"
        obj.u_id = cc
        obj.save()
    return render(request,'complaint/complaint.html')
def vcomp(request):
#     if request.method == "POST":
#         obj=Complaint()
#         obj.course_id = 1
#         obj.information = request.POST.get('INFORMATION')
#         obj.date = datetime.date.today()
#         obj.time = datetime.datetime.now()
#         obj.save()
# def complaint(request):
    return render(request,'complaint/complaint.html')

def vcomplaint(request):
    xyz = Complaint.objects.filter(replay="pending")
    context = {
        'xyzval': xyz
    }
    return render(request,'complaint/view complaint.html',context)

def vrply(request):
   cc = request.session["u_id"]
   obj=Complaint.objects.filter(u_id=cc)
   context={
       'objval':obj
   }

   return render(request,'complaint/view_reply.html',context)

def forward(request,idd):
    obj=Complaint.objects.get(c_id=idd)
    obj.status='forwored'

    obj.save()
    return vcomplaint(request)

def vcompandreplay(request):
    abc = Complaint.objects.all()
    context = {
        'abct': abc
    }
    return render(request,'complaint/view complaint and replay.html',context)
def reply(request,idd):
    # ck = request.session["u_id"]
    if request.method == "POST":
        obj = Complaint.objects.get(c_id=idd)
        obj.replay = request.POST.get('reply')
        obj.date = datetime.date.today()
        obj.time = datetime.datetime.now()
        obj.status = "pending"
        # obj.u_id = ck
        obj.save()
        return vcompandreplay(request)
    return render(request,'complaint/reply.html')