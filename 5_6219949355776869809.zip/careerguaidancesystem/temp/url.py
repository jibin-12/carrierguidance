from django.conf.urls import url
from temp import views
urlpatterns=[
    url(r'^index/',views.indexhome),
    url('^admin/',views.adminhome),
    url('^insttution/',views.institutionhome),
    url(r'^userhome/',views.userhome),
    # url('usrlog',views.userlog)
    ]