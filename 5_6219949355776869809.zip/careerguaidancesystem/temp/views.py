from django.shortcuts import render


# Create your views here.
def indexhome(request):
    return render(request,'temp/index.html')
def adminhome(request):
    return render(request,'temp/admin_home.html')
def institutionhome(request):
    return render(request,'temp/institution_home.html')
def userhome (request):
    return render(request,'temp/user_home.html')
# def userlog (request):
#     return render(request,'temp/user-log.html')
