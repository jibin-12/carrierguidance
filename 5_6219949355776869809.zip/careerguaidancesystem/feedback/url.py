from django.conf.urls import url
from feedback import views
urlpatterns=[
    url(r'^feedback/',views.feedback),
    url('^viewfeedback/',views.vfeedback),
    url('^adminviewfeeedback/',views.adminviewfeedback)
    ]