from django.shortcuts import render
from feedback.models import Feedback
import datetime
def feedback(request):
    cc= request.session["u_id"]
    if request.method=="POST":
        obj=Feedback()
        obj.feedback=request.POST.get('feedback')
        obj.u_id=cc
        obj.discription=request.POST.get('discription')
        obj.date=datetime.date.today()
        obj.save()
    return render(request,'feedback/FEEDBACK.HTML')
def adminviewfeedback(request):
    return render(request,'feedback/adminviewfeedback.html')
# def infeedback(request):
#     return render(request,'feedback/FEEDBACK.HTML')
def vfeedback(request):
    ben = Feedback.objects.all()
    context = {
        'benhar': ben
    }
    return render(request,'feedback/view feedback.html',context)

