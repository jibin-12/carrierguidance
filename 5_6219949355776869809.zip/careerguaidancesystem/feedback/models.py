from django.db import models

# Create your models here.
class Feedback(models.Model):
    f_id = models.AutoField(primary_key=True)
    u_id = models.IntegerField()
    discription = models.CharField(max_length=100)
    date = models.DateField()
    feedback = models.CharField(max_length=40)

    class Meta:
        managed = False
        db_table = 'feedback'

