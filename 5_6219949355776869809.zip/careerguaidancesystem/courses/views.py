from django.shortcuts import render
from courses.models import Courses
def courses(request):
    if request.method=="POST":
        obj=Courses()
        obj.course_name=request.POST.get('coursename')
        obj.duration=request.POST.get('duration')
        obj.fee=request.POST.get('fee')
        obj.discription=request.POST.get('dis')
        obj.status="pending"
        obj.save()
    return render(request, 'courses/adminaddcourse.html')
def edit(request,idd):
    objlist=Courses.objects.filter(course_id=idd)
    context={
        'obval':objlist,
    }
    if request.method=="POST":
        obj=Courses.objects.get(course_id=idd)
        obj.course_name = request.POST.get('coursename')
        obj.duration = request.POST.get('duration')
        obj.fee = request.POST.get('fee')
        obj.discription = request.POST.get('dis')
        obj.save()
        return managecourse(request)

    return render(request,'courses/edit.html',context)
def delete(request,idd):
    obj=Courses.objects.get(course_id=idd)
    obj.delete()
    return managecourse(request)

def managecourse(request):
    shi = Courses.objects.all()
    context = {
        'shibu': shi
    }
    return render(request, 'courses/manage course.html',context)

def vcourse(request):
    jib = Courses .objects.all()
    context = {
        'jibin': jib
    }
    return render(request, 'courses/view courses.html',context)
