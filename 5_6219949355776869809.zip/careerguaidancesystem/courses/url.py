from django.conf.urls import url
from courses import views
urlpatterns=[
    url('^adminaddcourse/',views.courses),
    url('^managecourse/',views.managecourse),
    url('^vcourse/',views.vcourse),
    url('edit/(?P<idd>\w+)',views.edit,name='edit'),
    url('delete/(?P<idd>\w+)',views.delete,name='delete')
]