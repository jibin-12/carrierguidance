from django.db import models

# Create your models here.
class Courses(models.Model):
    course_id = models.AutoField(primary_key=True)
    course_name = models.CharField(max_length=50)
    duration = models.CharField(max_length=30)
    fee = models.IntegerField()
    discription = models.CharField(max_length=100)
    status = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'courses'

