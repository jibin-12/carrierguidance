from django.shortcuts import render
from user_registration.models import UserRegistration
from login.models import Login
#Create your views here.
def userreg(request):
    if request.method=="POST":
        obj=UserRegistration()
        obj.first_name=request.POST.get('first name')
        obj.last_name=request.POST.get('lastname')
        obj.email=request.POST.get('email')
        obj.password=request.POST.get('password')
        obj.confirm_password=request.POST.get('confirmpassword')
        obj.phone_number=request.POST.get('phonenumber')
        obj.addres=request.POST.get('address')
        obj.post_code=request.POST.get('pincode')
        obj.dob=request.POST.get('dob')
        obj.qualification=request.POST.get('qualification')
        obj.mark=request.POST.get('mark')
        obj.school_college=request.POST.get('schoolcollegename')
        obj.save()
        ob=Login()
        ob.username=request.POST.get('phonenumber')
        ob.password=request.POST.get('password')
        ob.type="user"
        ob.u_id=obj.u_id
        ob.save()
    return render(request,'user_registration/userreg2.html')
def vuserreg(request):
    obj = UserRegistration.objects.all()
    context = {
        'objval': obj
    }
    return render(request,'user_registration/viewuserregistration.html',context)

def update(request):
    vc= request.session["u_id"]
    obj = UserRegistration.objects.get(u_id=vc)
    context = {
        'objval': obj
    }
    if request.method=="POST":
        obj = UserRegistration()
        obj.first_name = request.POST.get('first name')
        obj.last_name=request.POST.get('last name')
        obj.email = request.POST.get('email')
        obj.password = request.POST.get('password')
        obj.confirm_password = request.POST.get('confirm password')
        obj.phone_number = request.POST.get('NUMBER')
        obj.addres = request.POST.get('ADDRESS')
        obj.post_code=request.POST.get('PINCODE')
        obj.dob = request.POST.get('DOB')
        obj.qualification = request.POST.get('qualification')
        obj.mark = request.POST.get('Mark')
        obj.school_college = request.POST.get('name')
        obj.save()
        return vuserreg(request)
    return render(request,'user_registration/userreg.html',context)
