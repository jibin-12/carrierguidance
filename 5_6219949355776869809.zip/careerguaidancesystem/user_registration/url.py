from django.conf.urls import url
from user_registration import views
urlpatterns=[
    url(r'^userregistration/',views.userreg),
    url(r'^viewuserregistration/',views.vuserreg),
    url(r'^updateprofile/',views.update)
    ]