from django.db import models

# Create your models here.
class UserRegistration(models.Model):
    u_id = models.AutoField(primary_key=True)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    email = models.CharField(max_length=40)
    password = models.CharField(max_length=30)
    confirm_password = models.CharField(max_length=30)
    phone_number = models.CharField(max_length=30)
    addres = models.CharField(max_length=100)
    post_code = models.IntegerField()
    dob = models.DateField()
    qualification = models.CharField(max_length=100)
    mark = models.IntegerField()
    school_college = models.CharField(max_length=50)
    gender = models.CharField(max_length=10)

    class Meta:
        managed = False
        db_table = 'user_registration'

