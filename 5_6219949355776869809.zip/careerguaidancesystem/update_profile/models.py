from django.db import models

# Create your models here.
class UpdateProfile(models.Model):
    up_id = models.AutoField(primary_key=True)
    update_education_qualification = models.CharField(max_length=100)
    edit_mark_field = models.IntegerField(db_column='edit_mark_%')  # Field renamed to remove unsuitable characters. Field renamed because it ended with '_'.
    edit_college_school = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'update_profile'

