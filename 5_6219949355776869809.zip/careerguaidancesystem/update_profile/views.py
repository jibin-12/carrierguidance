from django.shortcuts import render
from update_profile.models import UpdateProfile
def updateprofile(request):
    if request.method=="POST":
        obj=UpdateProfile()
        obj.update_education_qualification=request.POST.get('qualification')
        obj.edit_mark_field= request.POST.get('Mark %')
        obj.edit_college_school=request.POST.get('"name')
        obj.save()
    return render(request,'update_profile/updateprofile.html')
def profile(request):
    return render(request,'update_profile/updateprofile.html')
