from django.conf.urls import url
from update_profile import views
urlpatterns=[
    url('^update_profile/',views.updateprofile)
    ]