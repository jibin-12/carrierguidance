from django.shortcuts import render
from trainee_registration.models import TraineeRegistration
# Create your views here.
def traineereg(request):
    if request.method=="POST":
        obj = TraineeRegistration()
        obj.name = request.POST.get('traineename')
        obj.phone_no = request.POST.get('number')
        obj.qualification = request.POST.get('qualification')
        obj.skill = request.POST.get('skills')
        obj.experience = request.POST.get('experience')
        obj.save()
    return render(request,'trainee_registration/traineereg.html')

# def trainee(request):
#     return render(request,'trainee_registration/traineereg.html')
