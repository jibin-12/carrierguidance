from django.db import models

# Create your models here.
class TraineeRegistration(models.Model):
    t_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=30)
    phone_no = models.CharField(max_length=30)
    qualification = models.CharField(max_length=100)
    skills = models.CharField(max_length=100)
    experience = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'trainee_registration'


