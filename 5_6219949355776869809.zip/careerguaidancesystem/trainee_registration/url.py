from django.conf.urls import url
from trainee_registration import views
urlpatterns=[
    url(r'^traineereg/',views.traineereg)
    ]