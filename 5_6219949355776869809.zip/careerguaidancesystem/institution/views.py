from django.shortcuts import render
from institution.models import Institution
from login.models import Login



def inst(request):
    return render(request,'course_information/institutionaddcourse.html')


def reginst(request):
    if request.method=="POST":
        obj=Institution()
        obj.name=request.POST.get('name')
        obj.email= request.POST.get('email')
        obj.password=request.POST.get('password')
        obj.phone_no=request.POST.get('phone number')
        obj.address=request.POST.get('address')
        obj.pin_code=request.POST.get('pin')
        obj.save()
        ob = Login()
        ob.username = request.POST.get('phone number')
        ob.password = request.POST.get('password')
        ob.type = "institution"
        ob.u_id = obj.i_id
        ob.save()
    return render(request,'institution/institutionreg.html')
def adminviewinst(request):
    return render(request,'institution/admin view institution.html')





def vinst(request):
    obj=Institution.objects.all()
    context={
        'objval':obj
    }

    return render(request,'institution/view institution.html',context)

