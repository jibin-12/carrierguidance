from django.conf.urls import url
from institution import views
urlpatterns=[
    url('^registration/',views.reginst),
    url('^viewinstitution/',views.vinst),
    url('^adminviewinst/',views.adminviewinst)
    ]
