from django.db import models

# Create your models here.
class Institution(models.Model):
    i_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=40)
    email = models.CharField(max_length=30)
    password = models.CharField(max_length=30)
    phone_no = models.CharField(max_length=30)
    address = models.CharField(max_length=100)
    pin_code = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'institution'
