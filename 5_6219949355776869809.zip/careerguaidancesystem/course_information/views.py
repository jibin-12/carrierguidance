from django.shortcuts import render
from course_information.models import CourseInformation
import datetime
def instaddcourse(request):
    cc= request.session["u_id"]
    if request.method=="POST":
        obj=CourseInformation()
        obj.course_id= cc
        obj.information= request.POST.get('INFORMATION')
        obj.date=datetime.date.today()
        obj.time=datetime.datetime.now()
        obj.save()
    return render(request,'course_information/institutionaddcourse.html')
def instaddcourses(request):
    return render(request,'course_information/institutionaddcourse.html')