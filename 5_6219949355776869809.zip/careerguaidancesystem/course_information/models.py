from django.db import models

# Create your models here.
class CourseInformation(models.Model):
    ci_id = models.AutoField(primary_key=True)
    course_id = models.IntegerField()
    information = models.CharField(max_length=100)
    date = models.DateField()
    time = models.TimeField()

    class Meta:
        managed = False
        db_table = 'course_information'


