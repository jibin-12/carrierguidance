from django.conf.urls import url
from course_information import views
urlpatterns=[
    url(r'^instaddcourse/',views.instaddcourse)
]