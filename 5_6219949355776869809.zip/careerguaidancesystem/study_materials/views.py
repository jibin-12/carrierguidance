from django.shortcuts import render
from study_materials.models import StudyMaterials
# Create your views here.
# def study(request):
#     if request.method == "POST":
#         obj = StudyMaterials()
#         obj.course=request.POST.get('course')
#         obj.years=request.POST.get('year')
#         obj.semester=request.POST.get('semester')
#         obj.syllbus=request.POST.get('syllabus')
#         obj.save()
#     return render(request,'study_materials/upstudymaterials.html')
# def studym(request):
#     return render(request,'study_materials/upstudymaterials.html')
# def vstudy(request):
#     return render(request,'study_materials/VIEW STUDY MATERIALS.HTML')

def addstudy(request):
    if request.method == "POST":
        ob = StudyMaterials()
        ob.course =  request.POST.get('course')
        ob.years = request.POST.get('year')
        ob.semester = request.POST.get('semester')
        ob.syllbus = request.POST.get('syllabus')
        ob.save()
    return render(request,'study_materials/upstudymaterials.html')
def vstudym(request):
    ada = StudyMaterials.objects.all()
    context = {
        'adarsh': ada
    }
    return render(request,'study_materials/VIEW STUDY MATERIALS.HTML',context)

