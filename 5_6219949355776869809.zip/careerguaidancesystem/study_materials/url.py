from django.conf.urls import url
from study_materials import views
urlpatterns=[
    # url(r'^studymaterial/',views.studym),
    # url(r'^studymaterials/',views.vstudy),
    # url(r'^upload/',views.study),
    url('add/',views.addstudy),
    url('vstudymaterials/',views.vstudym)
    ]