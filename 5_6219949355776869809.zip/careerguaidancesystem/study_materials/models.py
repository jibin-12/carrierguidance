from django.db import models

# Create your models here.
class StudyMaterials(models.Model):
    sm_id = models.AutoField(primary_key=True)
    course = models.CharField(max_length=50)
    years = models.TextField()  # This field type is a guess.
    semester = models.CharField(max_length=20)
    syllbus = models.CharField(max_length=300)

    class Meta:
        managed = False
        db_table = 'study_materials'
