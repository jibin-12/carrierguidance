from django.apps import AppConfig


class AddmissionDetailsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'addmission_details'
