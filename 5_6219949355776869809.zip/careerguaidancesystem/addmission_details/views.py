from django.shortcuts import render
from addmission_details.models import AddmissionDetails
from courses.models import Courses
# Create your views here.
def admissdet(request):
    jib = Courses.objects.all()
    context = {
        'jibin': jib
    }
    # cc= request.session["u_id"]
    if request.method=="POST":
        obj=AddmissionDetails()
        obj.course_id=request.POST.get('coursename')
        obj.discription=request.POST.get('DISCRIPTION')
        obj.save()


    return render(request,'addmission_details/addmissiondetails.html',context)
def addaddmissiond(requests):
    return render(requests,'addmission_details/addadmission details.html')
def viewaddmission(request):
    obj = AddmissionDetails.objects.all()
    context = {
        'objval': obj
    }

    return render(request,'addmission_details/view admission details.html',context)