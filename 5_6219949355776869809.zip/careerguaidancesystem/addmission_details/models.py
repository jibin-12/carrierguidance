from django.db import models
from courses.models import Courses

# Create your models here.
class AddmissionDetails(models.Model):
    a_id = models.AutoField(primary_key=True)
    # course_id = models.IntegerField()
    course=models.ForeignKey(Courses,to_field='course_id',on_delete=models.CASCADE)
    discription = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'addmission_details'

