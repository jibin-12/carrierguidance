from django.conf.urls import url
from addmission_details import views
urlpatterns=[
    url('^admis/',views.admissdet),
    url('^view/',views.viewaddmission),
    url('^addadmissiondetails/',views.addaddmissiond)
]