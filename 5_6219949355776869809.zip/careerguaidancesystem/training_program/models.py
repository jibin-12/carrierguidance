from django.db import models

# Create your models here.
class TrainingProgram(models.Model):
    tp_id = models.AutoField(primary_key=True)
    institution_id = models.IntegerField()
    course_name = models.CharField(max_length=100)
    discription = models.CharField(max_length=200)
    date = models.DateField()
    time = models.TimeField()
    phone_no = models.CharField(max_length=30)
    skills = models.CharField(max_length=100)
    tr_name = models.CharField(max_length=15)

    class Meta:
        managed = False
        db_table = 'training_program'

