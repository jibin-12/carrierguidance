from django.conf.urls import url
from training_program import views
urlpatterns=[
    url('^joiningprogram/',views.jointrainingprgrm),
    url('^schedulingprogram/',views.traineescheduling),
    url('^shedule/',views.shedule),
    url('^viewschedule/',views.vschedule)
]