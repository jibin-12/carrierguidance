from django.shortcuts import render
from training_program.models import TrainingProgram
import datetime
from courses.models import Courses
# Create your views here.
def jointrainingprgrm(request):
    vv=Courses.objects.all()
    context={
        'obval':vv,
    }
    if request.method == "POST":
        vbb=request.POST.get('COURSE NAME')
        vb=Courses.objects.filter(course_name=vbb)
        context={
            'ok':vb
        }
        # obj = TrainingProgram()
        # obj.course = request.POST.get('COURSE NAME')
        # obj.semester=request.POST.get('semester')
        # obj.syllbus=request.POST.get('choose file')
        # obj.save()
        return render(request, 'training_program/joiningtrainingprgm.html', context)
    return render(request,'training_program/joiningtrainingprgm.html',context)

def traineescheduling(request):
    if request.method == "POST":
        obj=TrainingProgram()
        obj.tr_name= request.POST.get('name')
        obj.date = datetime.date.today()
        obj.time = datetime.datetime.now()
        obj.institution_id=1
        obj.skills=request.POST.get('skills')
        obj.phone_no=request.POST.get('phonenumber')
        obj.save()
    return render(request, 'training_program/traineescheduling.html')
# def joinprgm(request):
#     return render(request,'training_program/joiningtrainingprgm.html')
# def scheduling(request):
#     return render(request,'training_program/SCHEDULING.HTML.HTML')



def shedule(request):
    cc= request.session["u_id"]
    if request.method == "POST":
        ob = TrainingProgram()
        ob.course_name = request.POST.get('coursename')
        ob.discription = "NA"
        ob.date = request.POST.get('date')
        ob.time = request.POST.get('time')
        ob.phone_no = request.POST.get('phone')
        ob.skills = request.POST.get('skills')
        ob.institution_id = cc

        ob.save()
    return render(request,'training_program/traineescheduling.html')
def vschedule(request):
    kha = TrainingProgram.objects.all()
    context = {
        'khalid': kha
    }
    return render(request,'training_program/SCHEDULING.HTML.HTML',context)
